
using Iteration_2;
using IterationTwo;
using NUnit.Framework;

[TestFixture]
public class BagTests
{
    private Bag bag;
    private Item item;
    private Bag innerBag;

    [SetUp]
    public void Init()
    {
        // Initialize the Bag with some Items before each test
        bag = new Bag(new string[] { "bag", "backpack" }, "Leather Bag", "A large bag made from leather.");
        item = new Item(new string[] { "rope" }, "Rope", "A long piece of sturdy rope.");
        innerBag = new Bag(new string[] { "small bag", "pouch" }, "Small Bag", "A small pouch for holding precious items.");

        // Add items to the bag
        bag.Inventory.Put(item);
        // Put a small bag inside the larger bag
        bag.Inventory.Put(innerBag);
    }

    [Test]
    public void TestBagLocatesItems()
    {
        Assert.AreEqual(item, bag.Locate("rope"));
        // Ensuring the item is still in the bag after being located
        Assert.IsTrue(bag.Inventory.HasItem("rope"));
    }

    [Test]
    public void TestBagLocatesItself()
    {
        Assert.AreEqual(bag, bag.Locate("bag"));
    }

    [Test]
    public void TestBagLocatesNothing()
    {
        Assert.IsNull(bag.Locate("sword"));
    }

    [Test]
    public void TestBagFullDescription()
    {
        // Setup adds a Rope to bag, which should be listed in the description
        string expectedDescription = "In the Leather Bag, you can see:Rope (rope)\nSmall Bag (small bag)";
        Assert.AreEqual(expectedDescription, bag.FullDescription.Trim());
    }

    [Test]
    public void TestBagInBag()
    {
        // Add another item to the inner bag
        Item gem = new Item(new string[] { "gem" }, "Gem", "A shiny, valuable gem.");
        innerBag.Inventory.Put(gem);

        // Ensure the outer bag can locate the inner bag
        Assert.AreEqual(innerBag, bag.Locate("small bag"));

        // The outer bag should not locate items within the inner bag
        Assert.IsNull(bag.Locate("gem"));

        // The inner bag should locate its own items
        Assert.AreEqual(gem, innerBag.Locate("gem"));
    }
}
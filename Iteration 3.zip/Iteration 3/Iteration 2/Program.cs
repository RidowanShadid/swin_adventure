﻿using System;

namespace IterationTwo
{


    class Program
    {
        static void Main(string[] args)
        {
            // Create a new player
            Player player = new Player("Hero", "A brave warrior");

            // Create some items
            Item sword = new Item(new string[] { "sword", "blade" }, "a sharp sword", "A fine blade capable of defeating enemies.");
            Item shield = new Item(new string[] { "shield", "protector" }, "a sturdy shield", "A strong shield for defense.");

            // Add items to the player's inventory
            player.Inventory.Put(sword);
            player.Inventory.Put(shield);

            // Demonstrate locating items
            Console.WriteLine("Locating 'sword': " + player.Locate("sword")?.ShortDescription);
            Console.WriteLine("Locating 'shield': " + player.Locate("shield")?.FullDescription);

            // Wait for user input to close
            Console.ReadLine();
        }
    }
}

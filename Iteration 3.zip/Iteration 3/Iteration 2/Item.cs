﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IterationTwo
{
    public class Item : GameObject
    {

        public Item(string[] ids, string name, string desc) : base(ids, name, desc)
        {

        }
        public virtual GameObject Locate(string id)
        {
            // Basic implementation or return null if this item isn't the one being located
            return AreYou(id) ? this : null;
        }
    }
}

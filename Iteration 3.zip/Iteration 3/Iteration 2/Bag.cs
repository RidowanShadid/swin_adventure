﻿using IterationTwo;
using System.Text;

namespace Iteration_2
{
    public class Bag : Item
    {
        private Inventory _inventory;

        public Bag(string[] ids, string name, string desc) : base(ids, name, desc)
        {
            _inventory = new Inventory();
        }

        public Inventory Inventory => _inventory; // Use expression body for read-only property

        public override string FullDescription
        {
            get
            {
                var description = new StringBuilder($"In the {Name}, you can see:");
                description.Append(_inventory.ItemList); // Assuming ItemList returns a formatted string
                return description.ToString();
            }
        }

        public override GameObject Locate(string id)
        {
            // Check if the bag itself is being located
            if (AreYou(id)) return this;

            // Otherwise, attempt to locate the item inside the bag's inventory
            return _inventory.Fetch(id);
        }
    }

}

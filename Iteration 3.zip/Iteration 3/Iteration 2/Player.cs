﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IterationTwo
{
    public class Player : GameObject
    {
        private Inventory _inventory;

        public Player(string name, string desc) : base( new string[] { "me", "inventory" }, name, desc)
        {
            _inventory = new Inventory();
        }

        public GameObject Locate(string id)
        {
            if (AreYou(id))
            {
                return this; //this returns it's own constructor
            }

            return _inventory.Fetch(id);
        }

        public override string FullDescription
        {
            get
            {
                var Carry = _inventory.ItemList;
                return $"You are {this.Name}, {this.Description}. You are carrying:\n{Carry}";
            }
        }

        public Inventory Inventory
        { 
            get
            {
                return _inventory;
            } 
        }
    }

}

﻿using IterationTwo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestIterationTwo
{
    public class TestsPlayer
    {
        [TestFixture]
        public class PlayerTests
        {
            private Player player;
            private Item sword;

            [SetUp]
            public void SetUp()
            {
                player = new Player("Hero", "A brave warrior");
                sword = new Item(new string[] { "sword", "blade" }, "a Sword", "A sharp weapon.");
                player.Inventory.Put(sword);
            }

            [Test]
            public void TestPlayerIdentifySelf()
            {
                Assert.IsTrue(player.AreYou("me"));
                Assert.IsTrue(player.AreYou("inventory"));
            }

            [Test]
            public void TestPlayerLocatesSelf()
            {
                var foundPlayer = player.Locate("me");
                Assert.AreEqual(player, foundPlayer);
            }

            [Test]
            public void TestPlayerLocatesItem()
            {
                var foundItem = player.Locate("sword");
                Assert.AreEqual(sword, foundItem);
            }

            [Test]
            public void TestPlayerDoesNotLocateNonexistentItem()
            {
                var foundItem = player.Locate("axe");
                Assert.IsNull(foundItem);
            }

            [Test]
            public void TestPlayerFullDescription()
            {
                string expectedDescription = "You are Hero, A brave warrior. You are carrying:\na Sword (sword)";
                Assert.AreEqual(expectedDescription, player.FullDescription);
            }
        }
    }
}

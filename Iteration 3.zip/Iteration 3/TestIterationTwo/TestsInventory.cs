﻿using IterationTwo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestIterationTwo
{
    public class TestsInventory
    {
        [TestFixture]
        public class InventoryTests
        {
            private Inventory inventory;
            private Item sword;
            private Item shield;

            [SetUp]
            public void SetUp()
            {
                inventory = new Inventory();
                sword = new Item(new string[] { "sword", "blade" }, "a Sword", "A sharp weapon.");
                shield = new Item(new string[] { "shield", "protector" }, "a Shield", "Used for protection.");

                inventory.Put(sword);
                inventory.Put(shield);
            }

            [Test]
            public void TestInventoryHasItem()
            {
                Assert.IsTrue(inventory.HasItem("sword"));
                Assert.IsTrue(inventory.HasItem("shield"));
            }

            [Test]
            public void TestInventoryDoesNotHaveItem()
            {
                Assert.IsFalse(inventory.HasItem("axe"));
            }

            [Test]
            public void TestFetchItem()
            {
                var fetchedItem = inventory.Fetch("sword");
                Assert.AreEqual(sword, fetchedItem);
            }

            [Test]
            public void TestTakeItem()
            {
                var item = inventory.Take("shield");
                Assert.AreEqual(shield, item);
                Assert.IsFalse(inventory.HasItem("shield"));
            }

            [Test]
            public void TestItemList()
            {
                string expectedList = "a Sword (sword)\na Shield (shield)";
                Assert.AreEqual(expectedList, inventory.ItemList);
            }
        }
    }
}

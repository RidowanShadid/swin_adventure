using System;
using System.Collections.Generic;
using NUnit.Framework;
using IterationTwo;
using System.Security.Cryptography;

namespace TestIterationTwo
{
    [TestFixture]
    public class ItemTests
    {
        private Item sword;

        [SetUp]
        public void Init()
        {
            // Initialize the sword Item before each test
            sword = new Item(new string[] { "sword", "blade" }, "a Sword", "A sharp weapon.");
        }

        [Test]
        public void TestItemIsIdentifiable()
        {
            // Using the 'sword' initialized in SetUp
            Assert.IsTrue(sword.AreYou("sword"));
            Assert.IsTrue(sword.AreYou("blade"));
            Assert.IsFalse(sword.AreYou("shield"));
        }

        [Test]
        public void TestShortDescription()
        {
            // Asserts the ShortDescription property using the 'sword' initialized in SetUp
            Assert.AreEqual("a Sword (sword)", sword.ShortDescription);
        }

        [Test]
        public void TestFullDescription()
        {
            // Asserts the FullDescription property using the 'sword' initialized in SetUp
            Assert.AreEqual("A sharp weapon.", sword.FullDescription);
        }
    }


}